
public interface Table_Store {

	public default void tableStore(){
		System.out.println("Table Stored");
	}
}
