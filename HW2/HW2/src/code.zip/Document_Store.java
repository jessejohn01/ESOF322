
public interface Document_Store {

	public default void documentStore(){
		System.out.println("A Document store was done.");
	}
}
