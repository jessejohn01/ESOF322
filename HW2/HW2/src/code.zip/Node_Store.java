
public interface Node_Store {

	public default void nodeStore(){
		System.out.println("A Node store is done.");
	}
}
